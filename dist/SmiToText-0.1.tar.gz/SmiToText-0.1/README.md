## 이 프로젝트는 형태소 분석, 자막 취합 등을 위한 프로젝트입니다. 




### * 추가 라이브러리 설치 방법 
#### 1. spacy tokenizer 를 위한 english 설치 
```
python -m spacy download en


python
import nltk
nltk.download()

```

