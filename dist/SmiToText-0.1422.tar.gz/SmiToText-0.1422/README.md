## 이 프로젝트는 형태소 분석, 자막 취합 등을 위한 프로젝트입니다. 




### * 추가 라이브러리 설치 방법 
#### 1. spacy tokenizer 를 위한 english 설치 
```
python -m spacy download en


python
import nltk
nltk.download()

```
#### 2. 카카오 형태소 분석기 설치
```
https://github.com/kakao/khaiii

https://github.com/kakao/khaiii/wiki/%EB%B9%8C%EB%93%9C-%EB%B0%8F-%EC%84%A4%EC%B9%98

```

